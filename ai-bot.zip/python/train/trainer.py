import asyncio, time
import torch
from torch.optim import Adam
from .ppo import ppo_loss, compute_gae
from .rollout import RolloutBuffer
from .league import League
from .curriculum import Curriculum
from .reward import PvPReward
from ..model.save_brain import save_brain
from ..model.export_onnx import export_onnx


class Trainer:
    def __init__(self, policy, ws_server, cfg, device="cuda",
                 rollout_len=512, export_dir="brains", mode="modern"):
        self.policy = policy.to(device)
        self.opt = Adam(policy.parameters(), lr=3e-4)
        self.ws_server = ws_server
        self.cfg = cfg
        self.device = device
        self.rollout_len = rollout_len
        self.export_dir = export_dir
        self.mode = mode
        self.league = League(device=device)
        self.curriculum = Curriculum()
        self.reward_fn = PvPReward(mode)
        self.iteration = 0
        self.norm_acc = {"n": 0, "sum": None, "sumsq": None}

    async def collect(self):
        """等所有 bot 攒够 rollout_len 步，合并成 batch"""
        buffers = {}
        while True:
            await asyncio.sleep(0.01)
            for bid, conn in self.ws_server.bots.items():
                await conn.step()
                if bid not in buffers:
                    buffers[bid] = RolloutBuffer(self.rollout_len)
                buf = buffers[bid]
                while len(conn.rollout) > 0:
                    obs, c, d, lp, v, r, done = conn.rollout.pop(0)
                    self._accum_norm(obs)
                    buf.add(obs, c, d, lp, r, done, v)
            if all(b.ready() for b in buffers.values()) and buffers:
                return buffers

    def _accum_norm(self, obs):
        import numpy as np
        o = np.asarray(obs, dtype=np.float64)
        if self.norm_acc["sum"] is None:
            self.norm_acc["sum"] = o.copy()
            self.norm_acc["sumsq"] = o * o
        else:
            self.norm_acc["sum"] += o
            self.norm_acc["sumsq"] += o * o
        self.norm_acc["n"] += 1

    def merge_batch(self, buffers):
        all_obs, all_c, all_d, all_lp = [], [], [], []
        all_r, all_done, all_v = [], [], []
        for buf in buffers.values():
            all_obs += buf.obs; all_c += buf.cont; all_d += buf.disc
            all_lp += buf.logp; all_r += buf.rew; all_done += buf.done; all_v += buf.val
        t = lambda x, dt: torch.tensor(x, dtype=dt, device=self.device)
        obs = t(all_obs, torch.float32); c = t(all_c, torch.float32)
        d = t(all_d, torch.long); lp = t(all_lp, torch.float32)
        r = t(all_r, torch.float32); dn = t(all_done, torch.float32)
        v = t(all_v, torch.float32)
        adv, ret = compute_gae(r, v, dn)
        return (obs, c, d, lp, adv, ret)

    def compute_norm(self):
        import numpy as np
        mean = self.norm_acc["sum"] / self.norm_acc["n"]
        var = self.norm_acc["sumsq"] / self.norm_acc["n"] - mean * mean
        std = np.sqrt(np.clip(var, 1e-6, None))
        return {"mean": mean.tolist(), "std": std.tolist()}

    def build_meta(self, tag, win_rate):
        return {
            "brain_id": f"pvp_{self.mode}_{tag}",
            "combat_mode": self.mode,
            "mc_version_range": ["1.9", "1.21"] if self.mode == "modern" else ["1.8", "1.8.9"],
            "obs_layout": {
                "self": [0, 13], "opponent": [13, 23],
                "env": [23, 39], "version": [39, 42],
            },
            "act_layout": {
                "continuous": ["move_forward", "move_strafe", "look_yaw", "look_pitch"],
                "discrete": {"jump": 2, "attack": 2, "use_item": 2,
                             "switch_slot": 9, "sprint": 2},
            },
            "train_stats": {"iter": self.iteration, "win_rate": win_rate},
        }

    async def run(self, total_iters=50000, export_every=500):
        for it in range(total_iters):
            buffers = await self.collect()
            batch = self.merge_batch(buffers)

            for _ in range(4):
                loss, pl, vl, ent = ppo_loss(self.policy, batch)
                self.opt.zero_grad(); loss.backward()
                torch.nn.utils.clip_grad_norm_(self.policy.parameters(), 0.5)
                self.opt.step()

            # 热更新推理端
            await self.ws_server.policy_server.update(self.policy.state_dict())

            if it % 10 == 0:
                self.league.add(self.policy)

            if it % export_every == 0:
                norm = self.compute_norm()
                meta = self.build_meta(str(it).zfill(6), 0.0)
                pt, mt = save_brain(self.policy, norm, meta, self.export_dir, str(it).zfill(6))
                export_onnx(self.policy, pt, pt.replace(".pt", ".onnx"))
                print(f"[export] iter={it} loss={loss.item():.3f} ent={ent:.3f}")

            self.iteration += 1