class PvPReward:
    def __init__(self, mode="modern"):
        self.mode = mode

    def compute(self, info, prev):
        r = 0.0
        dh = prev.get("opp_health", 20) - info.get("opp_health", 20)
        dr = prev.get("health", 20) - info.get("health", 20)
        r += dh * 0.1          # 造成伤害
        r -= dr * 0.1          # 受到伤害
        if info.get("kill"): r += 10.0
        if info.get("death"): r -= 10.0
        if self.mode == "modern":
            if info.get("attacked") and info.get("cooldown", 1.0) < 0.5:
                r -= 0.05
        else:
            if info.get("no_attack_ticks", 0) > 40:
                r -= 0.01
        r -= 0.001 * info.get("distance", 0)
        if info.get("timeout"):
            r -= 1.0
        return r