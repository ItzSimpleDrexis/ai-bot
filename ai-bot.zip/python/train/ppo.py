import torch
import torch.nn as nn

def compute_gae(rewards, values, dones, gamma=0.99, lam=0.95):
    adv = torch.zeros_like(rewards)
    last = 0.0
    for t in reversed(range(len(rewards))):
        mask = 1.0 - dones[t]
        nxt = values[t + 1] if t + 1 < len(values) else 0.0
        delta = rewards[t] + gamma * nxt * mask - values[t]
        last = delta + gamma * lam * mask * last
        adv[t] = last
    return adv, adv + values


def ppo_loss(policy, batch, clip=0.2, vf_coef=0.5, ent_coef=0.01):
    obs, cont, disc, old_logp, adv, ret = batch
    adv = (adv - adv.mean()) / (adv.std() + 1e-8)

    logp, v = policy.log_prob(obs, cont, disc)
    ratio = (logp - old_logp).exp()
    surr1 = ratio * adv
    surr2 = ratio.clamp(1 - clip, 1 + clip) * adv
    policy_loss = -torch.min(surr1, surr2).mean()
    value_loss = nn.functional.mse_loss(v, ret)
    entropy = policy.entropy(obs).mean()
    loss = policy_loss + vf_coef * value_loss - ent_coef * entropy
    return loss, policy_loss.item(), value_loss.item(), entropy.item()