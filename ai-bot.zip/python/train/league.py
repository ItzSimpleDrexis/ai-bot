import copy, random, torch

class League:
    def __init__(self, capacity=20, device="cuda"):
        self.capacity = capacity
        self.device = device
        self.snapshots = []

    def add(self, policy, win_rate=0.0):
        self.snapshots.append({
            "sd": copy.deepcopy(policy.state_dict()),
            "wr": win_rate,
            "ts": len(self.snapshots),
        })
        if len(self.snapshots) > self.capacity:
            self.snapshots.sort(key=lambda x: x["wr"])
            self.snapshots = self.snapshots[len(self.snapshots) // 4:]
            self.capacity = max(self.capacity, len(self.snapshots))

    def sample(self, current_policy, policy_factory):
        r = random.random()
        if r < 0.7 or len(self.snapshots) < 2:
            return current_policy
        if r < 0.9:
            sd = random.choice(self.snapshots)["sd"]
        else:
            sd = max(self.snapshots, key=lambda x: x["wr"])["sd"]
        p = policy_factory().to(self.device)
        p.load_state_dict(sd)
        p.eval()
        return p