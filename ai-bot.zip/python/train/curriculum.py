CURRICULUM = [
    {"stage": 0, "opponent": "random", "arena": "flat_small", "steps": 50_000},
    {"stage": 1, "opponent": "script", "arena": "flat_small", "steps": 200_000},
    {"stage": 2, "opponent": "self",   "arena": "flat_small", "steps": 500_000},
    {"stage": 3, "opponent": "league", "arena": "flat_medium", "steps": 1_000_000},
    {"stage": 4, "opponent": "league", "arena": "obstacles", "steps": 2_000_000},
]

class Curriculum:
    def __init__(self):
        self.stage = 0
        self.step = 0

    def tick(self, n=1):
        self.step += n
        cur = CURRICULUM[self.stage]
        if self.step >= cur["steps"] and self.stage < len(CURRICULUM) - 1:
            self.stage += 1
            self.step = 0
            return True
        return False

    def config(self):
        return CURRICULUM[self.stage]