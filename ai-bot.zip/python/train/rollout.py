import torch

class RolloutBuffer:
    def __init__(self, capacity):
        self.capacity = capacity
        self.reset()

    def reset(self):
        self.obs, self.cont, self.disc = [], [], []
        self.logp, self.rew, self.done, self.val = [], [], [], []

    def add(self, obs, cont, disc, logp, rew, done, val):
        self.obs.append(obs); self.cont.append(cont); self.disc.append(disc)
        self.logp.append(logp); self.rew.append(rew)
        self.done.append(done); self.val.append(val)

    def ready(self):
        return len(self.obs) >= self.capacity

    def tensors(self, device):
        t = lambda x, dt: torch.tensor(x, dtype=dt, device=device)
        return (t(self.obs, torch.float32), t(self.cont, torch.float32),
                t(self.disc, torch.long), t(self.logp, torch.float32),
                t(self.rew, torch.float32), t(self.done, torch.float32),
                t(self.val, torch.float32))