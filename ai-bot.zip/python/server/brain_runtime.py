import json
import numpy as np
import onnxruntime as ort

class BrainRuntime:
    def __init__(self, onnx_path, meta_path):
        with open(meta_path) as f:
            self.meta = json.load(f)
        self.session = ort.InferenceSession(
            onnx_path, providers=["CPUExecutionProvider"])
        self.obs_dim = self.meta["obs_dim"]
        self.norm_mean = np.array(self.meta["norm_stats"]["mean"], dtype=np.float32)
        self.norm_std = np.array(self.meta["norm_stats"]["std"], dtype=np.float32)
        self.disc_names = list(self.meta["act_layout"]["discrete"].keys())
        self.disc_sizes = list(self.meta["act_layout"]["discrete"].values())

    def normalize(self, obs_vec):
        return ((obs_vec - self.norm_mean) / (self.norm_std + 1e-8)).astype(np.float32)

    def flatten_obs(self, obs_dict):
        order = ["self", "opponent", "env", "version"]
        vec = np.concatenate([np.asarray(obs_dict[k], dtype=np.float32) for k in order])
        if vec.shape[0] != self.obs_dim:
            raise ValueError(f"obs dim mismatch: {vec.shape[0]} != {self.obs_dim}")
        return vec

    def act(self, obs_dict):
        obs = self.normalize(self.flatten_obs(obs_dict))
        feeds = {"obs": obs.reshape(1, -1)}
        out = self.session.run(None, feeds)
        mu, std, logits = out[0][0], out[1][0], out[2][0]
        # 确定性：连续取 mu，离散取 argmax
        cont = np.clip(mu, -1, 1)
        disc, off = [], 0
        for n in self.disc_sizes:
            slice_ = logits[off:off + n]
            disc.append(int(np.argmax(slice_)))
            off += n
        return self.build_action(cont, disc)

    def build_action(self, cont, disc):
        a = {
            "move_forward": float(cont[0]),
            "move_strafe": float(cont[1]),
            "look_yaw": float(cont[2]),
            "look_pitch": float(cont[3]),
        }
        for name, v in zip(self.disc_names, disc):
            a[name] = int(v)
        return a