from pydantic import BaseModel
from typing import Literal, Dict, List, Any

class HelloMsg(BaseModel):
    type: Literal["hello"] = "hello"
    bot_id: str
    mc_version: str
    combat_mode: str              # modern | legacy
    obs_dim: int = 42

class ObsMsg(BaseModel):
    type: Literal["obs"] = "obs"
    seq: int
    ts: float
    obs: Dict[str, List[float]]
    done: bool = False
    info: Dict[str, Any] = {}

class ActMsg(BaseModel):
    type: Literal["act"] = "act"
    seq: int
    action: Dict[str, Any]

class EventMsg(BaseModel):
    type: Literal["event"] = "event"
    event: str                    # death | kill | respawn | kicked | error
    data: Dict[str, Any] = {}

class ResetMsg(BaseModel):
    type: Literal["reset"] = "reset"
    spawn: List[float] | None = None