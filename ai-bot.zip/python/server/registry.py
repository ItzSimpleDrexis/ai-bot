import json, os

class BrainRegistry:
    def __init__(self, brains_dir, registry_file, default_map):
        self.brains_dir = brains_dir
        self.registry_file = registry_file
        self.default_map = default_map
        self.entries = {}
        self.reload()

    def reload(self):
        if os.path.exists(self.registry_file):
            with open(self.registry_file) as f:
                self.entries = json.load(f)
        else:
            self.entries = {"brains": {}, "default_modern": None, "default_legacy": None}

    def resolve(self, combat_mode: str) -> str:
        """按模式选 brain_id，优先 registry 的 default，回退 config"""
        key = f"default_{combat_mode}"
        bid = self.entries.get(key) or self.default_map.get(combat_mode)
        if bid and bid in self.entries.get("brains", {}):
            return bid
        # 回退：模式内胜率最高的
        candidates = [(k, v.get("win_rate", 0)) for k, v in self.entries.get("brains", {}).items()
                      if v.get("combat_mode") == combat_mode]
        if not candidates:
            raise RuntimeError(f"no brain available for mode={combat_mode}")
        return max(candidates, key=lambda x: x[1])[0]

    def path(self, brain_id: str):
        return os.path.join(self.brains_dir, f"{brain_id}.onnx"), \
               os.path.join(self.brains_dir, f"{brain_id}.meta.json")