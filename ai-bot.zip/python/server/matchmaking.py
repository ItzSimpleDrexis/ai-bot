import itertools
from typing import Dict, List, Optional

class Matchmaker:
    """配对 bot，让 PVP 对局成对出现；也负责给 bot 下发 spawn 位置"""
    def __init__(self):
        self.sessions: Dict[str, "BotSession"] = {}
        self.pairs: Dict[str, str] = {}       # bot_id -> opponent_id
        self.spawns = [(0, 64, 0), (0, 64, 10), (20, 64, 0), (20, 64, 10)]
        self._spawn_iter = itertools.cycle(self.spawns)

    def register(self, session):
        self.sessions[session.bot_id] = session
        self._try_pair(session)

    def unregister(self, bot_id):
        opp = self.pairs.pop(bot_id, None)
        if opp: self.pairs.pop(opp, None)
        self.sessions.pop(bot_id, None)

    def _try_pair(self, new_session):
        # 找同模式、未配对的 bot
        for bid, s in self.sessions.items():
            if bid == new_session.bot_id: continue
            if bid in self.pairs: continue
            if s.combat_mode != new_session.combat_mode: continue
            self.pairs[new_session.bot_id] = bid
            self.pairs[bid] = new_session.bot_id
            return
        # 没对手：先单机（训练/评估场景）

    def opponent_of(self, bot_id) -> Optional[str]:
        return self.pairs.get(bot_id)

    def next_spawn(self):
        return list(next(self._spawn_iter))