from collections import defaultdict
import time

class Stats:
    def __init__(self):
        self.per_bot = defaultdict(lambda: {
            "rounds": 0, "kills": 0, "deaths": 0,
            "damage_dealt": 0.0, "damage_taken": 0.0,
            "last_seen": 0, "events": defaultdict(int),
        })

    def record_event(self, bot_id, event, data):
        s = self.per_bot[bot_id]
        s["last_seen"] = time.time()
        s["events"][event] += 1
        if event == "kill": s["kills"] += 1
        if event == "death": s["deaths"] += 1
        if "damage_dealt" in data: s["damage_dealt"] += data["damage_dealt"]
        if "damage_taken" in data: s["damage_taken"] += data["damage_taken"]

    def record_round(self, bot_id, info):
        self.per_bot[bot_id]["rounds"] += 1

    def summary(self):
        out = {}
        for bid, s in self.per_bot.items():
            rounds = max(1, s["rounds"])
            out[bid] = {
                "rounds": s["rounds"],
                "kills": s["kills"], "deaths": s["deaths"],
                "kda": round((s["kills"] + 1) / (s["deaths"] + 1), 2),
                "win_rate": round((s["kills"] - s["deaths"]) / rounds, 3),
                "avg_damage_dealt": round(s["damage_dealt"] / rounds, 2),
                "avg_damage_taken": round(s["damage_taken"] / rounds, 2),
                "last_seen": s["last_seen"],
                "events": dict(s["events"]),
            }
        return out