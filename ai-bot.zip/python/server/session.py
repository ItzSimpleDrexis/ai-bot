import asyncio, time
from .brain_runtime import BrainRuntime

class BotSession:
    def __init__(self, ws, hello, brain: BrainRuntime, cfg, stats):
        self.ws = ws
        self.bot_id = hello["bot_id"]
        self.mc_version = hello["mc_version"]
        self.combat_mode = hello["combat_mode"]
        self.brain = brain
        self.cfg = cfg
        self.stats = stats

        self.obs_queue: asyncio.Queue = asyncio.Queue(maxsize=8)
        self.last_seq = -1
        self.last_action = None
        self.alive = True
        self.lock = asyncio.Lock()
        self.tick_ms = int(1000 / cfg.action_rate_hz)
        self.deadline = 0

    async def run(self):
        """主循环：等 obs → 推理 → 回 act；超时沿用上一动作"""
        while self.alive:
            try:
                msg = await asyncio.wait_for(
                    self.obs_queue.get(), timeout=self.tick_ms / 1000 * 3)
            except asyncio.TimeoutError:
                # 长时间无 obs，发心跳或判定掉线
                if time.time() * 1000 - self.deadline > 5000:
                    await self.on_disconnect("no_obs")
                continue

            if msg["seq"] <= self.last_seq:
                continue
            self.last_seq = msg["seq"]
            self.deadline = time.time() * 1000

            if msg.get("done"):
                self.stats.record_round(self.bot_id, msg.get("info", {}))

            try:
                action = await asyncio.to_thread(self.brain.act, msg["obs"])
                self.last_action = action
            except Exception as e:
                # 推理失败：沿用上一动作 + 上报
                action = self.last_action or self._noop()
                await self.send_event("error", {"reason": str(e)})

            await self.send_act(msg["seq"], action)

    async def on_obs(self, msg):
        try:
            self.obs_queue.put_nowait(msg)
        except asyncio.QueueFull:
            # 丢最旧
            try: self.obs_queue.get_nowait()
            except: pass
            self.obs_queue.put_nowait(msg)

    async def send_act(self, seq, action):
        async with self.lock:
            await self.ws.send_json({"type": "act", "seq": seq, "action": action})

    async def send_event(self, event, data=None):
        async with self.lock:
            await self.ws.send_json({"type": "event", "event": event, "data": data or {}})

    async def send_reset(self, spawn=None):
        async with self.lock:
            await self.ws.send_json({"type": "reset", "spawn": spawn})

    async def on_event(self, msg):
        ev = msg.get("event")
        self.stats.record_event(self.bot_id, ev, msg.get("data", {}))
        if ev == "death":
            await self.send_reset()
        elif ev == "kicked":
            self.alive = False

    async def on_disconnect(self, reason):
        self.alive = False
        await self.send_event("disconnect", {"reason": reason})

    def _noop(self):
        return {"move_forward": 0.0, "move_strafe": 0.0, "look_yaw": 0.0,
                "look_pitch": 0.0, "jump": 0, "attack": 0, "use_item": 0,
                "switch_slot": 0, "sprint": 0}