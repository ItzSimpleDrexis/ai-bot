import argparse, asyncio, json, time
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
import uvicorn

from .config import ServerConfig
from .registry import BrainRegistry
from .brain_runtime import BrainRuntime
from .session import BotSession
from .matchmaking import Matchmaker
from .stats import Stats

cfg = ServerConfig()
registry = BrainRegistry(cfg.brains_dir, cfg.registry_file, cfg.default_brain)
stats = Stats()
matchmaker = Matchmaker()
brain_cache: dict[str, BrainRuntime] = {}
app = FastAPI()

def get_brain(combat_mode: str) -> BrainRuntime:
    bid = registry.resolve(combat_mode)
    if bid not in brain_cache:
        onnx, meta = registry.path(bid)
        brain_cache[bid] = BrainRuntime(onnx, meta)
    return brain_cache[bid]

# ---------- WebSocket 动作通道 ----------
@app.websocket("/ws")
async def ws_endpoint(ws: WebSocket):
    await ws.accept()
    try:
        hello = await ws.receive_json()
        assert hello["type"] == "hello"
    except Exception:
        await ws.close(); return

    if len(matchmaker.sessions) >= cfg.max_bots:
        await ws.send_json({"type": "event", "event": "rejected", "data": {"reason": "max_bots"}})
        await ws.close(); return

    try:
        brain = get_brain(hello["combat_mode"])
    except Exception as e:
        await ws.send_json({"type": "event", "event": "rejected", "data": {"reason": str(e)}})
        await ws.close(); return

    session = BotSession(ws, hello, brain, cfg, stats)
    matchmaker.register(session)
    asyncio.create_task(session.run())
    await ws.send_json({"type": "welcome", "brain_id": brain.meta["brain_id"],
                        "tick_rate": cfg.action_rate_hz})

    try:
        while True:
            msg = await ws.receive_json()
            if msg["type"] == "obs":
                await session.on_obs(msg)
            elif msg["type"] == "event":
                await session.on_event(msg)
    except WebSocketDisconnect:
        pass
    finally:
        session.alive = False
        matchmaker.unregister(session.bot_id)

# ---------- HTTP 管理接口 ----------
@app.get("/health")
def health():
    return {"status": "ok", "bots": len(matchmaker.sessions),
            "brains_loaded": list(brain_cache.keys())}

@app.get("/bots")
def bots():
    return {"bots": list(matchmaker.sessions.keys()), "pairs": matchmaker.pairs}

@app.get("/stats")
def get_stats():
    return stats.summary()

@app.get("/brains")
def list_brains():
    registry.reload()
    return registry.entries

@app.post("/brains/switch")
async def switch_brain(mode: str, brain_id: str):
    registry.entries[f"default_{mode}"] = brain_id
    brain_cache.pop(brain_id, None)   # 强制下次重载
    return {"ok": True, "mode": mode, "brain_id": brain_id}

@app.post("/bots/{bot_id}/reset")
async def reset_bot(bot_id: str, x: float = 0, y: float = 64, z: float = 0):
    s = matchmaker.sessions.get(bot_id)
    if not s: return {"ok": False, "reason": "not found"}
    await s.send_reset([x, y, z])
    return {"ok": True}

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--host", default=cfg.host)
    p.add_argument("--port", type=int, default=cfg.port)
    p.add_argument("--brains-dir", default=cfg.brains_dir)
    a = p.parse_args()
    cfg.brains_dir = a.brains_dir
    uvicorn.run(app, host=a.host, port=a.port, log_level="info")

if __name__ == "__main__":
    main()