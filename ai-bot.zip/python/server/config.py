from dataclasses import dataclass, field
from typing import Dict

@dataclass
class ServerConfig:
    host: str = "0.0.0.0"
    port: int = 8765
    brains_dir: str = "brains"
    registry_file: str = "brains/registry.json"
    action_rate_hz: int = 20
    # 每个 combat_mode 默认加载哪个 brain
    default_brain: Dict[str, str] = field(default_factory=lambda: {
        "modern": "pvp_modern_v1",
        "legacy": "pvp_legacy_v1",
    })
    # 单 tick 超时（ms），超时沿用上一动作
    act_timeout_ms: int = 50
    max_bots: int = 32