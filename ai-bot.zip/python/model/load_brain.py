import torch
from .config import PolicyConfig
from .policy import PvPPolicy

def load_brain(pt_path, device="cpu"):
    brain = torch.load(pt_path, map_location=device)
    cfg = PolicyConfig.from_dict(brain["config"])
    policy = PvPPolicy(cfg).to(device)
    policy.load_state_dict(brain["state_dict"])
    policy.eval()
    return policy, brain["norm_stats"], brain["meta"]