import torch
import torch.nn as nn
from torch.distributions import Normal, Categorical
from .config import PolicyConfig


class PvPPolicy(nn.Module):
    def __init__(self, cfg: PolicyConfig):
        super().__init__()
        self.cfg = cfg
        self.trunk = nn.Sequential(
            nn.Linear(cfg.obs_dim, cfg.hidden), nn.ReLU(),
            nn.Linear(cfg.hidden, cfg.hidden), nn.ReLU(),
        )
        self.cont_mu = nn.Linear(cfg.hidden, cfg.cont_dim)
        self.cont_logstd = nn.Parameter(torch.zeros(cfg.cont_dim))
        self.disc_logits = nn.Linear(cfg.hidden, sum(cfg.disc_sizes))
        self.value = nn.Linear(cfg.hidden, 1)

    def forward(self, obs):
        h = self.trunk(obs)
        mu = torch.tanh(self.cont_mu(h))
        std = self.cont_logstd.exp().expand_as(mu)
        logits = self.disc_logits(h)
        v = self.value(h).squeeze(-1)
        return mu, std, logits, v

    def split_logits(self, logits):
        return torch.split(logits, self.cfg.disc_sizes, dim=-1)

    def act(self, obs, deterministic=False):
        """返回 (cont, disc, logp, value)，供采样与推理共用"""
        mu, std, logits, v = self.forward(obs)
        if deterministic:
            cont = mu
        else:
            cont = Normal(mu, std).sample().clamp(-1, 1)
        parts = self.split_logits(logits)
        disc_list, logp = [], Normal(mu, std).log_prob(cont).sum(-1)
        for i, p in enumerate(parts):
            dist = Categorical(logits=p)
            d = torch.argmax(p, dim=-1) if deterministic else dist.sample()
            disc_list.append(d)
            if not deterministic:
                logp = logp + dist.log_prob(d)
        disc = torch.stack(disc_list, dim=-1)
        return cont, disc, logp, v

    def log_prob(self, obs, cont, disc):
        mu, std, logits, v = self.forward(obs)
        lp = Normal(mu, std).log_prob(cont).sum(-1)
        for i, p in enumerate(self.split_logits(logits)):
            lp = lp + Categorical(logits=p).log_prob(disc[:, i])
        return lp, v

    def entropy(self, obs):
        mu, std, logits, _ = self.forward(obs)
        ent = Normal(mu, std).entropy().sum(-1)
        for p in self.split_logits(logits):
            ent = ent + Categorical(logits=p).entropy()
        return ent