import torch
import onnx

def export_onnx(policy, pt_path, onnx_path, opset=17):
    policy.eval()
    dummy = torch.randn(1, policy.cfg.obs_dim)
    torch.onnx.export(
        policy, dummy, onnx_path,
        input_names=["obs"],
        output_names=["mu", "std", "logits", "value"],
        dynamic_axes={"obs": {0: "batch"}},
        opset_version=opset,
    )
    onnx.checker.check_model(onnx.load(onnx_path))
    return onnx_path