from dataclasses import dataclass, asdict, field
from typing import Tuple

@dataclass
class PolicyConfig:
    obs_dim: int = 42
    hidden: int = 256
    cont_dim: int = 4
    disc_sizes: Tuple[int, ...] = (2, 2, 2, 9, 2)   # jump, attack, use_item, switch_slot, sprint
    disc_names: Tuple[str, ...] = ("jump", "attack", "use_item", "switch_slot", "sprint")

    def to_dict(self):
        d = asdict(self)
        d["disc_sizes"] = list(self.disc_sizes)
        d["disc_names"] = list(self.disc_names)
        return d

    @classmethod
    def from_dict(cls, d):
        return cls(
            obs_dim=d["obs_dim"], hidden=d["hidden"], cont_dim=d["cont_dim"],
            disc_sizes=tuple(d["disc_sizes"]), disc_names=tuple(d["disc_names"]),
        )