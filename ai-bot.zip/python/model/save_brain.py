import json, os
import torch
from .config import PolicyConfig

def save_brain(policy, norm_stats, meta_extra, out_dir, tag):
    os.makedirs(out_dir, exist_ok=True)
    cfg = policy.cfg
    brain = {
        "format_version": 1,
        "config": cfg.to_dict(),
        "state_dict": policy.state_dict(),
        "norm_stats": norm_stats,
        "meta": meta_extra,
    }
    pt_path = os.path.join(out_dir, f"brain_{tag}.pt")
    torch.save(brain, pt_path)

    meta = {
        "brain_id": meta_extra["brain_id"],
        "combat_mode": meta_extra["combat_mode"],
        "mc_version_range": meta_extra.get("mc_version_range", []),
        "obs_dim": cfg.obs_dim,
        "obs_layout": meta_extra["obs_layout"],
        "act_layout": meta_extra["act_layout"],
        "norm_stats": norm_stats,
        "action_rate_hz": 20,
        "train_stats": meta_extra.get("train_stats", {}),
    }
    meta_path = os.path.join(out_dir, f"brain_{tag}.meta.json")
    with open(meta_path, "w") as f:
        json.dump(meta, f, indent=2)
    return pt_path, meta_path