import argparse, asyncio, torch
from python.model.config import PolicyConfig
from python.model.policy import PvPPolicy
from python.env.ws_server import WSServer
from python.train.trainer import Trainer


async def main(args):
    cfg = PolicyConfig(obs_dim=args.obs_dim)
    policy = PvPPolicy(cfg).to(args.device)
    server = WSServer(policy, port=args.py_port)

    trainer = Trainer(
        policy, server, cfg, device=args.device,
        rollout_len=args.rollout_len, export_dir=args.export_dir, mode=args.mode,
    )

    asyncio.create_task(server.start())
    print(f"[server] ws://0.0.0.0:{args.py_port} mode={args.mode}")
    await trainer.run(total_iters=args.total_iters, export_every=args.export_every)


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--mode", choices=["modern", "legacy"], default="modern")
    p.add_argument("--obs-dim", type=int, default=42)
    p.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    p.add_argument("--py-port", type=int, default=8765)
    p.add_argument("--rollout-len", type=int, default=512)
    p.add_argument("--total-iters", type=int, default=50000)
    p.add_argument("--export-every", type=int, default=500)
    p.add_argument("--export-dir", default="brains")
    asyncio.run(main(p.parse_args()))