from pydantic import BaseModel
from typing import Literal, Dict, List, Any

class HelloMsg(BaseModel):
    type: Literal["hello"] = "hello"
    bot_id: str
    mc_version: str
    combat_mode: str          # "modern" | "legacy"
    obs_dim: int

class ObsMsg(BaseModel):
    type: Literal["obs"] = "obs"
    seq: int
    ts: float
    obs: Dict[str, List[float]]
    reward: float
    done: bool
    info: Dict[str, Any] = {}

class ActMsg(BaseModel):
    type: Literal["act"] = "act"
    seq: int
    action: Dict[str, Any]