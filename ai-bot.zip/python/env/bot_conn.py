import asyncio, json
import numpy as np

class BotConn:
    def __init__(self, ws, hello: dict, policy_server):
        self.ws = ws
        self.bot_id = hello["bot_id"]
        self.mc_version = hello["mc_version"]
        self.combat_mode = hello["combat_mode"]
        self.policy_server = policy_server
        self.obs_queue: asyncio.Queue = asyncio.Queue(maxsize=32)
        self.last_seq = -1
        self.rollout = []   # (obs, cont, disc, logp, v, reward, done)

    async def on_obs(self, msg: dict):
        await self.obs_queue.put(msg)

    async def step(self):
        """从队列取一条 obs，推理，回动作"""
        msg = await self.obs_queue.get()
        if msg["seq"] <= self.last_seq:
            return  # 丢弃错位
        self.last_seq = msg["seq"]

        obs_vec = self.flatten_obs(msg["obs"])
        cont, disc, logp, v = await self.policy_server.act(obs_vec, self.combat_mode)
        self.rollout.append((obs_vec, cont, disc, logp, v, msg["reward"], msg["done"]))

        action = self.build_action(cont, disc)
        await self.ws.send(json.dumps({"type": "act", "seq": msg["seq"], "action": action}))

    def flatten_obs(self, obs_dict):
        # 严格按 obs_layout 顺序拼接
        order = ["self", "opponent", "env", "version"]
        return np.concatenate([obs_dict[k] for k in order]).astype(np.float32)

    def build_action(self, cont, disc):
        return {
            "move_forward": float(cont[0]), "move_strafe": float(cont[1]),
            "look_yaw": float(cont[2]), "look_pitch": float(cont[3]),
            "jump": int(disc[0]), "attack": int(disc[1]), "use_item": int(disc[2]),
            "switch_slot": int(disc[3]), "sprint": int(disc[4]),
        }

    def drain_rollout(self):
        r, self.rollout = self.rollout, []
        return r