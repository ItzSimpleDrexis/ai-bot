import asyncio, json
import websockets
from .bot_conn import BotConn
from .protocol import HelloMsg

class PolicyServer:
    def __init__(self, policy):
        self.policy = policy
        self.lock = asyncio.Lock()

    async def act(self, obs_vec, mode):
        import torch
        async with self.lock:
            with torch.no_grad():
                x = torch.from_numpy(obs_vec).unsqueeze(0).to(
                    next(self.policy.parameters()).device)
                cont, disc, logp, v = self.policy.act(x)
            return (cont[0].cpu().numpy(), disc[0].cpu().numpy(),
                    float(logp[0]), float(v[0]))

    async def update(self, state_dict):
        async with self.lock:
            self.policy.load_state_dict(state_dict)


class WSServer:
    def __init__(self, policy, host="0.0.0.0", port=8765):
        self.policy_server = PolicyServer(policy)
        self.bots: dict[str, BotConn] = {}
        self.host, self.port = host, port

    async def handler(self, ws):
        raw = await ws.recv()
        hello = json.loads(raw)
        assert hello["type"] == "hello"
        conn = BotConn(ws, hello, self.policy_server)
        self.bots[conn.bot_id] = conn
        try:
            async for raw in ws:
                msg = json.loads(raw)
                if msg["type"] == "obs":
                    await conn.on_obs(msg)
        finally:
            self.bots.pop(conn.bot_id, None)

    async def start(self):
        async with websockets.serve(self.handler, self.host, self.port):
            await asyncio.Future()