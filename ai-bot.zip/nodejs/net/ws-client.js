const WebSocket = require('ws')
const logger = require('../utils/logger')

class WSClient {
  constructor(url, { onMessage, onOpen, reconnectMs = 3000 } = {}) {
    this.url = url
    this.onMessage = onMessage
    this.onOpen = onOpen
    this.reconnectMs = reconnectMs
    this.ws = null
    this.closed = false
    this.connect()
  }

  connect() {
    this.ws = new WebSocket(this.url)
    this.ws.on('open', () => {
      logger.info('[ws] connected', this.url)
      if (this.onOpen) this.onOpen()
    })
    this.ws.on('message', (raw) => {
      const msg = raw.toString()
      if (this.onMessage) this.onMessage(msg)
    })
    this.ws.on('close', () => {
      if (this.closed) return
      logger.warn('[ws] closed, reconnect in', this.reconnectMs)
      setTimeout(() => this.connect(), this.reconnectMs)
    })
    this.ws.on('error', (e) => logger.error('[ws] error', e.message))
  }

  send(raw) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(raw)
      return true
    }
    return false
  }

  close() { this.closed = true; this.ws && this.ws.close() }
}
module.exports = { WSClient }