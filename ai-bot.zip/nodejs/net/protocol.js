function encodeHello({ botId, mcVersion, combatMode, obsDim }) {
  return JSON.stringify({ type: 'hello', bot_id: botId, mc_version: mcVersion,
                          combat_mode: combatMode, obs_dim: obsDim })
}
function encodeObs({ seq, ts, obs, done, info }) {
  return JSON.stringify({ type: 'obs', seq, ts, obs, done, info })
}
function encodeEvent(event, data = {}) {
  return JSON.stringify({ type: 'event', event, data })
}
function decode(raw) {
  try { return JSON.parse(raw) } catch { return null }
}
module.exports = { encodeHello, encodeObs, encodeEvent, decode }