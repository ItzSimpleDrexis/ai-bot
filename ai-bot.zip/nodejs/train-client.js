#!/usr/bin/env node
const { program } = require('commander')
const config = require('./config')
const { createBot } = require('./core/bot')
const { buildObs } = require('./core/observer')
const { applyAction } = require('./core/executor')
const { WSClient } = require('./net/ws-client')
const { encodeHello, encodeObs, encodeEvent, decode } = require('./net/protocol')
const { nowSec } = require('./utils/clock')
const logger = require('./utils/logger')

program
  .requiredOption('--server <host>')
  .option('--port <n>', 'MC port', parseInt, 25565)
  .requiredOption('--py <url>', 'Python WS url')
  .requiredOption('--id <botId>')
  .option('--username <name>', 'MC username', null)
  .option('--version <v>', 'MC version', null)
  .option('--auth <mode>', 'offline|microsoft', 'offline')
  .parse()
const opts = program.opts()

let bot, rules, ws
let seq = 0
let lastAction = null
let lastActTs = 0
let pendingAction = null   // 存最新到达的 act

async function onSpawn(b) {
  rules = b.rules
  const combatMode = rules.isModern ? 'modern' : 'legacy'
  ws.send(encodeHello({
    botId: opts.id, mcVersion: b.version, combatMode, obsDim: 42,
  }))
  logger.info(`[${opts.id}] ready, mode=${combatMode}`)
}

function onWsMessage(raw) {
  const msg = decode(raw)
  if (!msg) return
  if (msg.type === 'act') {
    // 只接受最新的 seq，丢弃过期的
    if (msg.seq >= seq - 1) {
      pendingAction = msg.action
      lastActTs = nowSec()
    }
  } else if (msg.type === 'reset') {
    if (bot && msg.spawn) {
      bot.chat(`/tp ${msg.spawn[0]} ${msg.spawn[1]} ${msg.spawn[2]}`)
    }
  } else if (msg.type === 'welcome') {
    logger.info(`[${opts.id}] welcome brain=${msg.brain_id}`)
  } else if (msg.type === 'event') {
    logger.info(`[${opts.id}] server event`, msg)
  }
}

function tick() {
  if (!bot || !bot.entity || !rules) return

  // 1. 执行上一 tick 收到的动作（或兜底）
  let act = pendingAction
  if (!act || nowSec() - lastActTs > config.py.actTimeoutMs / 1000) {
    act = lastAction || noop()
  }
  applyAction(bot, act, rules)
  lastAction = act
  pendingAction = null

  // 2. 采集 obs 上报
  const obs = buildObs(bot, rules)
  ws.send(encodeObs({
    seq, ts: nowSec(), obs,
    done: bot.health <= 0,
    info: {
      health: bot.health, food: bot.food,
      distance: obs.opponent[3],
      cooldown: rules.progress(),
      attacked: act.attack === 1,
    },
  }))
  seq++
}

function noop() {
  return { move_forward: 0, move_strafe: 0, look_yaw: 0, look_pitch: 0,
           jump: 0, attack: 0, use_item: 0, switch_slot: 0, sprint: 0 }
}

function startBot() {
  const username = opts.username || opts.id
  bot = createBot(
    { host: opts.server, port: opts.port, username, auth: opts.auth, version: opts.version },
    {
      onSpawn,
      onEnd: () => setTimeout(startBot, 5000),
    },
  )
  bot.on('death', () => {
    ws.send(encodeEvent('death', {}))
  })
  bot.on('kicked', (r) => ws.send(encodeEvent('kicked', { reason: r })))
}

async function main() {
  ws = new WSClient(opts.py, {
    onMessage: onWsMessage,
    onOpen: () => logger.info(`[${opts.id}] ws connected`),
    reconnectMs: config.py.reconnectMs,
  })
  startBot()
  setInterval(tick, config.tickMs)
}

process.on('SIGINT', () => {
  logger.info('shutting down')
  if (ws) ws.close()
  if (bot) bot.quit()
  process.exit(0)
})

main()