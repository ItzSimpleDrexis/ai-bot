module.exports = {
  // MC 服务器
  mc: {
    host: '127.0.0.1',
    port: 25565,
    version: null,          // null = 自动探测；建议显式指定
    auth: 'offline',
    username: null,         // 由 CLI 覆盖
  },
  // Python 服务端
  py: {
    url: 'ws://127.0.0.1:8765/ws',
    reconnectMs: 3000,
    actTimeoutMs: 150,
  },
  // 大脑
  brain: {
    onnxDir: 'brains',
    brainId: null,          // null = 按版本从 registry 选
    registryFile: 'brains/registry.json',
  },
  // 行为
  tickMs: 50,               // 20Hz
  maxHealthNoFood: 20,
}