const { nowSec } = require('../utils/clock')

class ModernRules {
  constructor(bot, version) {
    this.bot = bot
    this.version = version
    this.isModern = true
    this.lastAttackSec = -999
    this.cooldownTable = this._build(version)
    this.weaponName = 'hand'
  }

  _build(v) {
    // 单位：秒。按 wiki attack speed 表
    const table = { sword: 1.6, axe: 1.0, pickaxe: 1.2, shovel: 1.0, hand: 4.0 }
    // 1.9/1.10 与 1.11+ 略有差异，这里统一用 1.11+ 标准
    return table
  }

  _weaponKey() {
    const item = this.bot.heldItem
    if (!item) return 'hand'
    const n = item.name
    if (n.includes('sword')) return 'sword'
    if (n.includes('axe')) return 'axe'
    if (n.includes('pickaxe')) return 'pickaxe'
    if (n.includes('shovel')) return 'shovel'
    return 'hand'
  }

  cooldownDuration() {
    const speed = this.cooldownTable[this._weaponKey()] || 4.0
    return 1.0 / speed
  }

  progress() {
    const dur = this.cooldownDuration()
    const elapsed = nowSec() - this.lastAttackSec
    return Math.min(1.0, elapsed / dur)
  }

  canAttack() { return this.progress() > 0.9 }

  markAttack() { this.lastAttackSec = nowSec() }

  isBlocking() {
    const item = this.bot.heldItem
    return !!(item && item.name.includes('shield') && this.bot.getControlState('sneak'))
  }

  obsExtras() {
    return [this.progress(), this.cooldownDuration(), 1]
  }
}
module.exports = { ModernRules }