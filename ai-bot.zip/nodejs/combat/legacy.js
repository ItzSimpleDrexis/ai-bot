const { nowSec } = require('../utils/clock')

class LegacyRules {
  constructor(bot, version) {
    this.bot = bot
    this.version = version
    this.isModern = false
    this.lastAttackSec = -999
  }
  progress() { return 1.0 }
  canAttack() { return true }
  markAttack() { this.lastAttackSec = nowSec() }
  isBlocking() {
    const item = this.bot.heldItem
    return !!(item && item.name.includes('sword') && this.bot.getControlState('use_item'))
  }
  obsExtras() { return [1.0, 0.0, 0] }
}
module.exports = { LegacyRules }