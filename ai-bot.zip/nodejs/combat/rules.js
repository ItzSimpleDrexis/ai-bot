const { ModernRules } = require('./modern')
const { LegacyRules } = require('./legacy')

function createCombatRules(bot) {
  const v = bot.version || '1.20.4'
  const major = parseFloat(v)
  if (major < 1.9) return new LegacyRules(bot, v)
  return new ModernRules(bot, v)
}
module.exports = { createCombatRules }