#!/usr/bin/env node
const fs = require('fs')
const path = require('path')
const { program } = require('commander')
const config = require('./config')
const { createBot } = require('./core/bot')
const { buildObs } = require('./core/observer')
const { applyAction } = require('./core/executor')
const { Brain } = require('./core/brain')
const { normalize } = require('./core/normalize')
const logger = require('./utils/logger')

program
  .requiredOption('--server <host>')
  .option('--port <n>', 'MC port', parseInt, 25565)
  .requiredOption('--brain <id>', 'brain id, e.g. pvp_modern_v1')
  .option('--username <name>', 'MC username', 'AI_Bot')
  .option('--version <v>', 'MC version', null)
  .option('--auth <mode>', 'offline|microsoft', 'offline')
  .option('--brains-dir <dir>', 'brains directory', 'brains')
  .parse()
const opts = program.opts()

let bot, rules, brain
let running = false
let lastAction = null

function loadBrain(brainId) {
  const onnx = path.join(opts.brainsDir, `${brainId}.onnx`)
  const meta = path.join(opts.brainsDir, `${brainId}.meta.json`)
  if (!fs.existsSync(onnx) || !fs.existsSync(meta)) {
    throw new Error(`brain files not found: ${onnx} / ${meta}`)
  }
  return Brain.load(onnx, meta)
}

async function onSpawn(b) {
  rules = b.rules
  logger.info(`[${opts.username}] spawned v=${b.version} mode=${rules.isModern ? 'modern' : 'legacy'}`)
  // 校验模式匹配
  const expected = rules.isModern ? 'modern' : 'legacy'
  if (brain.meta.combat_mode !== expected) {
    logger.error(`brain mode=${brain.meta.combat_mode} but server is ${expected}`)
  }
  running = true
}

async function tick() {
  if (!running || !bot || !bot.entity || !rules) return
  try {
    const obsDict = buildObs(bot, rules)
    const vec = normalize(obsDict, brain.meta)
    const out = await brain.forward(vec)
    const act = brain.decode(out)
    applyAction(bot, act, rules)
    lastAction = act
  } catch (e) {
    logger.error('tick failed', e.message)
    if (lastAction) applyAction(bot, lastAction, rules)
  }
}

function startBot() {
  bot = createBot(
    { host: opts.server, port: opts.port, username: opts.username,
      auth: opts.auth, version: opts.version },
    { onSpawn, onEnd: () => { running = false; setTimeout(startBot, 5000) } },
  )
  bot.on('death', () => logger.info(`[${opts.username}] died, respawn`))
  bot.on('kicked', (r) => logger.warn(`[${opts.username}] kicked`, r))
}

async function main() {
  brain = await loadBrain(opts.brain)
  logger.info(`brain loaded: ${brain.meta.brain_id} (dim=${brain.obsDim})`)
  startBot()
  setInterval(tick, config.tickMs)
}

process.on('SIGINT', () => {
  logger.info('shutting down')
  if (bot) bot.quit()
  process.exit(0)
})

main().catch(e => { logger.error(e); process.exit(1) })