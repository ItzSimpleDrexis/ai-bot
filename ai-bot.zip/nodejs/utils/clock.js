const t0 = process.hrtime.bigint()
function nowSec() {
  return Number(process.hrtime.bigint() - t0) / 1e9
}
module.exports = { nowSec }