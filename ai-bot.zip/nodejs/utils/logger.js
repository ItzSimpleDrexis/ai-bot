function ts() { return new Date().toISOString().slice(11, 23) }
module.exports = {
  info: (...a) => console.log(`[${ts()}]`, ...a),
  warn: (...a) => console.warn(`[${ts()}] WARN`, ...a),
  error: (...a) => console.error(`[${ts()}] ERR`, ...a),
}