const { nowSec } = require('../utils/clock')
const { findOpponent } = require('./observer')

function applyAction(bot, act, rules) {
  // 移动
  bot.setControlState('forward', act.move_forward > 0.3)
  bot.setControlState('back', act.move_forward < -0.3)
  bot.setControlState('left', act.move_strafe > 0.3)
  bot.setControlState('right', act.move_strafe < -0.3)
  bot.setControlState('jump', act.jump === 1)
  bot.setControlState('sprint', act.sprint === 1)

  // 视角
  bot.entity.yaw -= act.look_yaw * 0.1
  bot.entity.pitch = clamp(bot.entity.pitch + act.look_pitch * 0.1, -Math.PI / 2, Math.PI / 2)

  // 切物品
  if (act.switch_slot >= 0) bot.setQuickBarSlot(act.switch_slot)

  // 使用物品（格挡/盾）
  if (act.use_item === 1) bot.activateItem()

  // 攻击：模型输出 + 规则校验
  if (act.attack === 1 && rules.canAttack()) {
    const target = findOpponent(bot)
    if (target && target.position.distanceTo(bot.entity.position) <= 3.0) {
      bot.attack(target)
      rules.markAttack()
    }
  }
}

function clamp(x, a, b) { return Math.max(a, Math.min(b, x)) }
module.exports = { applyAction }