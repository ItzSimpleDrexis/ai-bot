const mineflayer = require('mineflayer')
const { pathfinder } = require('mineflayer-pathfinder')
const { createCombatRules } = require('../combat/rules')
const logger = require('../utils/logger')

function createBot(opts, { onSpawn, onEnd } = {}) {
  const bot = mineflayer.createBot({
    host: opts.host, port: opts.port,
    username: opts.username,
    auth: opts.auth || 'offline',
    version: opts.version || false,
  })

  bot.loadPlugin(pathfinder)

  bot.once('spawn', async () => {
    bot.rules = createCombatRules(bot)
    logger.info(`[${opts.username}] spawned, version=${bot.version}, mode=${bot.rules.isModern ? 'modern' : 'legacy'}`)
    if (onSpawn) await onSpawn(bot)
  })

  bot.on('error', (e) => logger.error(`[${opts.username}] error`, e.message))
  bot.on('kicked', (r) => logger.warn(`[${opts.username}] kicked`, r))
  bot.on('end', (reason) => {
    logger.warn(`[${opts.username}] end`, reason)
    if (onEnd) onEnd(bot, reason)
  })

  bot.on('death', () => logger.info(`[${opts.username}] died`))

  return bot
}
module.exports = { createBot }