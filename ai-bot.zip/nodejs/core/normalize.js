function normalize(obsDict, meta) {
  const order = ['self', 'opponent', 'env', 'version']
  const vec = []
  for (const k of order) {
    for (const x of obsDict[k]) vec.push(x)
  }
  const mean = meta.norm_stats.mean, std = meta.norm_stats.std
  for (let i = 0; i < vec.length; i++) {
    vec[i] = (vec[i] - mean[i]) / (std[i] + 1e-8)
  }
  return vec
}
module.exports = { normalize }