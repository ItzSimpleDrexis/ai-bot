const ort = require('onnxruntime-node')
const fs = require('fs')
const path = require('path')

class Brain {
  static async load(onnxPath, metaPath) {
    const meta = JSON.parse(fs.readFileSync(metaPath, 'utf8'))
    const session = await ort.InferenceSession.create(onnxPath)
    return new Brain(session, meta)
  }

  constructor(session, meta) {
    this.session = session
    this.meta = meta
    this.discNames = Object.keys(meta.act_layout.discrete)
    this.discSizes = Object.values(meta.act_layout.discrete)
    this.obsDim = meta.obs_dim
  }

  async forward(obsVec) {
    const t = new ort.Tensor('float32', Float32Array.from(obsVec), [1, this.obsDim])
    const out = await this.session.run({ obs: t })
    return out
  }

  decode(out) {
    const mu = Array.from(out.mu.data)
    const logits = Array.from(out.logits.data)
    const act = {
      move_forward: clamp(mu[0], -1, 1),
      move_strafe: clamp(mu[1], -1, 1),
      look_yaw: clamp(mu[2], -1, 1),
      look_pitch: clamp(mu[3], -1, 1),
    }
    let off = 0
    for (let i = 0; i < this.discNames.length; i++) {
      const n = this.discSizes[i]
      const slice = logits.slice(off, off + n)
      act[this.discNames[i]] = argmax(slice)
      off += n
    }
    return act
  }
}

function clamp(x, a, b) { return Math.max(a, Math.min(b, x)) }
function argmax(arr) {
  let bi = 0, bv = -Infinity
  for (let i = 0; i < arr.length; i++) if (arr[i] > bv) { bv = arr[i]; bi = i }
  return bi
}

module.exports = { Brain }