const { nowSec } = require('../utils/clock')

function toBotFrame(dx, dy, dz, yaw) {
  const cos = Math.cos(-yaw), sin = Math.sin(-yaw)
  return [dx * cos - dz * sin, dy, dx * sin + dz * cos]
}

function findOpponent(bot) {
  const myPos = bot.entity.position
  let best = null, bestD = 8
  for (const id in bot.entities) {
    const e = bot.entities[id]
    if (!e || e === bot.entity) continue
    if (e.type !== 'player' && e.type !== 'mob') continue
    const d = e.position.distanceTo(myPos)
    if (d < bestD) { best = e; bestD = d }
  }
  return best
}

function buildObs(bot, rules) {
  const p = bot.entity.position
  const v = bot.entity.velocity
  const yaw = bot.entity.yaw, pitch = bot.entity.pitch
  const onGround = bot.entity.onGround ? 1 : 0

  const opp = findOpponent(bot)
  let rel = [0, 0, 0], dist = 8, oppHp = 20, oppGround = 1, oppBlock = 0, oppItem = 0, oppYaw = 0, oppPitch = 0
  if (opp) {
    const dx = opp.position.x - p.x, dy = opp.position.y - p.y, dz = opp.position.z - p.z
    rel = toBotFrame(dx, dy, dz, yaw)
    dist = Math.hypot(dx, dy, dz)
    oppHp = 20  // Mineflayer 不直接给玩家血量，留默认
    oppGround = opp.onGround ? 1 : 0
    oppBlock = 0
    oppItem = opp.heldItem ? 1 : 0
    oppYaw = opp.yaw || 0
    oppPitch = opp.pitch || 0
  }

  const self = [
    v.x, v.y, v.z, yaw, pitch,
    onGround,
    bot.getControlState('sprint') ? 1 : 0,
    bot.getControlState('sneak') ? 1 : 0,
    bot.health / 20, bot.food / 20,
    rules.progress(),
    rules.isBlocking() ? 1 : 0,
    Math.min(1, (nowSec() - rules.lastAttackSec) / 20),
  ]
  const opponent = [
    rel[0], rel[1], rel[2], dist,
    oppHp / 20, oppGround, oppBlock, oppItem, oppYaw, oppPitch,
  ]
  // env 16 维：脚下方块/头顶/四周碰撞
  const env = new Array(16).fill(0)
  const below = bot.blockAt(p.offset(0, -1, 0))
  env[0] = below ? below.id % 256 : 0
  const head = bot.blockAt(p.offset(0, 2, 0))
  env[1] = head && head.boundingBox === 'block' ? 1 : 0
  for (let i = 0; i < 4; i++) {
    const dirs = [[1,0],[-1,0],[0,1],[0,-1]][i]
    const b = bot.blockAt(p.offset(dirs[0], 0, dirs[1]))
    env[2 + i] = b && b.boundingBox === 'block' ? 1 : 0
  }
  const version = rules.obsExtras()
  return { self, opponent, env, version }
}

module.exports = { buildObs, findOpponent }